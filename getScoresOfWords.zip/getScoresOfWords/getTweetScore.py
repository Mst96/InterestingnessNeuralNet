#!/usr/bin/python
class getTweetScore:
    import csv
    import sys
    tweet = 'Make America Great Again!'
    str1 = ''.join(tweet)
    tweet = str1.lower()

    words = []
    with open('wordbag.txt', newline='') as inputfile:
        words = list(csv.reader(inputfile))

    wordscores = []
    with open('normalisedwordscores.txt', newline='') as inputfile:
        wordscores = list(csv.reader(inputfile))

    wordsInTweet = tweet.split()
    numberOfWords = len(wordsInTweet)
    score = 0
    wordsFound = 0
    positioninlist = 0

    for i in words:
        
        for j in wordsInTweet:
            str1 = ''.join(i)
            str2 = ''.join(e for e in j if e.isalnum())
            if str1 == str2:
                wordsFound = wordsFound + 1
                str3 = ''.join(wordscores[positioninlist])
                print(str3)
                score = score + float(str3)
        positioninlist = positioninlist + 1

    score = score / wordsFound
    print(score)
