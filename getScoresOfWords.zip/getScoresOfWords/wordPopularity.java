import java.io.*;
import java.util.*;
import java.lang.String;

public class wordPopularity {
	
	private String path;
	
	public wordPopularity(String filepath) {
		path = filepath;
	}

	public static void main(String[ ] args) throws IOException {

		String filename = "trumptop1000.txt";
		String filename2 = "wordbag.txt";
		
		try {
			wordPopularity file = new wordPopularity(filename);
			wordPopularity file2 = new wordPopularity(filename2);
			String[] lines = file.OpenSecondFile();
			String[][] lines2 = file2.OpenFile();
			int[] output = new int[lines.length]; 
			
			int i;
			for (i = 0; i < lines2.length; i++) {
				int score = 0;
				String[] tweet = lines.split("\\s+");
				if (Arrays.asList(tweet).contains(lines2[i])){ 
					score = score + (1000-i);
				}
				output[i] = score;
				System.out.println(output[i]);
			}
		}
		catch (IOException e)
		{
		}
		

	}

	public String[] OpenFile() throws IOException {
		
		FileReader fr = new FileReader(path);
		BufferedReader br = new BufferedReader(fr);
		
		int noOfLines = readLines();
		String textData[] = new String[noOfLines];
		
		int i;
		for (i = 0; i < noOfLines; i++) {
			textData[i] = br.readLine().toLowerCase();
			textData[i] = textData[i].replaceAll("[^a-zA-Z0-9]+", "");
			System.out.println(textData[i]);
		}
		
		br.close();
		return textData;
		
	}

	public String[] OpenSecondFile() throws IOException {
		
		FileReader fr = new FileReader(path);
		BufferedReader br = new BufferedReader(fr);
		
		int noOfLines = readLines();
		String textData[] = new String[noOfLines];
		
		int i;
		for (i = 0; i < noOfLines; i++) {
			textData[i] = br.readLine().toLowerCase();
			System.out.println(textData[i]);
		}
		
		br.close();
		return textData;
		
	}
	
	public int readLines() throws IOException {

		FileReader fileToRead = new FileReader(path);
		BufferedReader bf = new BufferedReader(fileToRead);
		
		String aLine;
		int noOfLines = 0;
		
		while ((aLine = bf.readLine()) != null) {
			noOfLines++;
		}
		bf.close();
		return noOfLines;
		
	}
	
}