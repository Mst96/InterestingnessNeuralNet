#!/usr/bin/python
class getScores:
    import csv

    def normalise(lst):
        s = max(lst)
        norm = [float(i) / s for i in lst]
        return norm

    words = []
    with open('wordbag.txt', newline='') as inputfile:
        words = list(csv.reader(inputfile))


    tweets = []
    with open('trumptweets.txt', newline='') as inputfile:
        tweets = list(csv.reader(inputfile))

    tweets2 = []
    for i in tweets:
        str1 = ''.join(i)
        tweets2.append(str1.split())

    wordscores = []
    for i in words:
        score = 0
        found = 0
        positioninlist = 0
        for j in tweets2:
            positioninlist = positioninlist + 1
            str1 = ''.join(i)
            str2 = ''.join(j)
            str2.split()
            if str1 in str2:
                score = score + (len(tweets2) - positioninlist)
                found = found + 1
        if found < 10:
            score = 0;
        else:
            score = score/found
        wordscores.append(score)


    writingfile = open('wordscores.txt', 'w')
    for item in wordscores:
        writingfile.write("%s\n" % item)

    norm = normalise(wordscores)

    writingfile = open('normalisedwordscores.txt', 'w')
    for item in norm:
        writingfile.write("%s\n" % item)

    print('done')
